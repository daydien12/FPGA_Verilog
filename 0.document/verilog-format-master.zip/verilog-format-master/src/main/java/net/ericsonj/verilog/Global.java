package net.ericsonj.verilog;

/**
 *
 * @author Ericson Joseph <ericsonjoseph@gmail.com>
 *
 * Create on Feb 16, 2019 8:41:34 PM
 */
public class Global {

    public static final String VERSION = "1.0.1";
    
}
